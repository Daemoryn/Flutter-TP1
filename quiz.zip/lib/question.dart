import 'package:flutter/material.dart';

class Question extends StatelessWidget {
  final String questionText;
  final bool isCorrect;
  final String url;

  const Question(
      {required this.questionText, required this.isCorrect, required this.url});

  @override
  Widget build(BuildContext context) {
    return Text(questionText,
        style: const TextStyle(fontSize: 20, color: Colors.white));
  }
}
