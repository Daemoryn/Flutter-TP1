import 'package:flutter/material.dart';
import 'package:quiz/question.dart';
import 'package:animate_do/animate_do.dart';

class QuizPage extends StatefulWidget {
  const QuizPage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<QuizPage> createState() => QuizPageState();
}

class QuizPageState extends State<QuizPage> {
  Question question1 = const Question(
      url: 'images/zidane.jpg',
      questionText: "La France a gagner la coupe du Monde 98.",
      isCorrect: true);
  Question question2 = const Question(
      url: 'images/miel.jpg',
      questionText: "Seul un aliment ne se déteriore jamais : le miel.",
      isCorrect: true);
  Question question3 = const Question(
      url: 'images/langue.jpg',
      questionText: "Le muscle le plus puissant du corps est la langue.",
      isCorrect: false);
  late final List<Question> questions = <Question>[
    question1,
    question2,
    question3
  ];
  int index = 0;
  int score = 0;
  int scorePrecedent = 0;
  int tentatives = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: const Text('Questions/Réponses'), centerTitle: true),
      backgroundColor: Colors.black87,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Row(
              children: [
                FadeInDown(
                    child: Container(
                  child: Text("Tentatives : " + tentatives.toString(),
                      style:
                          const TextStyle(fontSize: 20, color: Colors.yellow)),
                  color: Colors.black54,
                  padding: const EdgeInsets.all(20.0),
                )),
                FadeInDown(
                    child: Container(
                  child: Text("Score : " + score.toString(),
                      style:
                          const TextStyle(fontSize: 20, color: Colors.white)),
                  color: Colors.black54,
                  padding: const EdgeInsets.all(20.0),
                )),
                FadeInDown(
                    child: Container(
                  child: Text("Ancien score : " + scorePrecedent.toString(),
                      style:
                          const TextStyle(fontSize: 20, color: Colors.white60)),
                  color: Colors.black54,
                  padding: const EdgeInsets.all(20.0),
                )),
              ],
            ),
            FadeInDown(
                child: Image.asset(
              questions[index].url,
              width: 500,
            )),
            FadeInUp(
              child: Container(
                child: questions[index],
                color: Colors.black38,
                padding: const EdgeInsets.all(20.0),
              ),
            ),
            FadeInUp(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.green, onPrimary: Colors.black),
                      onPressed: () {
                        checkAnswer(true, context);
                      },
                      child: const Text("Vrai",
                          style: TextStyle(
                            fontSize: 50,
                          ))),
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.red, onPrimary: Colors.black),
                      onPressed: () {
                        checkAnswer(false, context);
                      },
                      child:
                          const Text("Faux", style: TextStyle(fontSize: 50))),
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.white24, onPrimary: Colors.black),
                      onPressed: () {
                        nextQuestion();
                      },
                      child: const Icon(Icons.navigate_next_rounded, size: 60)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  checkAnswer(bool userChoice, BuildContext context) {
    String text;
    if (questions[index].isCorrect == userChoice) {
      text = 'Vous avez répondu juste !';
      setState(() {
        score++;
      });
    } else {
      text = 'Ce n\'est pas la bonne réponse :/';
    }
    final snackBar =
        SnackBar(content: Text(text, style: const TextStyle(fontSize: 20)));
    ScaffoldMessenger.of(context).showSnackBar(snackBar);

    nextQuestion();
  }

  nextQuestion() {
    setState(() {
      if (index < questions.length - 1) {
        index++;
      } else {
        final snackBar = SnackBar(
            content: Text(
                "C'est la fin du Quiz, vous avez un score de : " +
                    score.toString() +
                    " !",
                style: const TextStyle(fontSize: 20)));
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
        scorePrecedent = score;
        index = 0;
        score = 0;
        tentatives++;
      }
    });
  }
}
