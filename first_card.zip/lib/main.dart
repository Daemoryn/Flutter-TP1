import 'package:first_card/person.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const FirstCard());
}

class FirstCard extends StatelessWidget {
  const FirstCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'First Card',
      theme: ThemeData(
        primarySwatch: Colors.grey,
      ),
      home: const FirstCardPage(title: 'First Card'),
    );
  }
}

class FirstCardPage extends StatefulWidget {
  const FirstCardPage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<FirstCardPage> createState() => FirstCardPageState();
}

class FirstCardPageState extends State<FirstCardPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text('First Card'), centerTitle: true),
        backgroundColor: Colors.grey,
        body: const Person(
            firstname: "Dae",
            lastname: "Moryn",
            email: "daemoryn@gmail.com",
            network: "daemoryn.com",
            url: "images/avatar.png"));
  }
}
