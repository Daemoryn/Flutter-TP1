import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';

class Person extends StatelessWidget {
  final String firstname;
  final String lastname;
  final String email;
  final String network;
  final String url;

  const Person(
      {required this.firstname,
      required this.lastname,
      required this.email,
      required this.network,
      required this.url});

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
            alignment: Alignment.center,
            width: 300,
            height: 200,
            padding: const EdgeInsets.all(20.0),
            decoration: BoxDecoration(
                color: Colors.black54, border: Border.all(width: 1.0)),
            child: Stack(alignment: Alignment.center, children: <Widget>[
              Container(
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                ),
                child: Image.asset(url, width: 100),
                margin: const EdgeInsets.only(bottom: 80),
              ),
              Column(children: [
                Text(firstname + " " + lastname,
                    style: const TextStyle(fontSize: 12, color: Colors.white)),
                Text(email,
                    style: const TextStyle(fontSize: 12, color: Colors.white)),
                Text(network,
                    style: const TextStyle(fontSize: 12, color: Colors.white)),
              ]),
            ])));
  }
}
