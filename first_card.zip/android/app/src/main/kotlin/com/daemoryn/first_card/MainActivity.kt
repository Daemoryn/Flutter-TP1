package com.daemoryn.first_card

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
